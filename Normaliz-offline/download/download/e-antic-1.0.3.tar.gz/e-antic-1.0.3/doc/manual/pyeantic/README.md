pyeantic documentation
======================

This directory contains pyeantic specific parts of the documentation written
for [Sphinx](https://sphinx-doc.org).
