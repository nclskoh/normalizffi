.. _realalg_interface:

Realalg Interface
=================

.. automodule:: pyeantic.realalg_conversion
