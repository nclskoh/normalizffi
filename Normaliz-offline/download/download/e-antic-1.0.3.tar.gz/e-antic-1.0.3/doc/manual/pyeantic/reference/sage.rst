.. _sage_interface:

SageMath Interface
==================

.. automodule:: pyeantic.real_embedded_number_field
